CREATE DATABASE IF NOT EXISTS `hibernate` DEFAULT CHARACTER SET utf8;

USE hibernate;

GRANT ALL ON hibernate.* TO 'hibuser'@'localhost' identified by 'password'; 

commit;
